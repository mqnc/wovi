
#ifndef SCL_CUSTOM_HPP
#define SCL_CUSTOM_HPP

#include "simpleCL.h"

sclSoft sclGetCLSoftwareFromString(char* source, char* name, sclHard hardware );

#endif
